#!/bin/bash
echo "Memory information"
free -m
echo "Disk information"
df -h